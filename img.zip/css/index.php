<?php 
echo "
<div style='border: 1px solid #000;padding: .5rem;background: #edefec;display: flex;flex-direction: column;font-family: sans-serif;align-items: center;justify-content: center;text-align: center;'>
	<h1 style='color: #E71F47;margin: .8rem 0;font-size: 2.35rem;width: 100%;background: #FFE1E1;border: 1px solid #E71F47;padding: .5rem 0;'>ATENCIÓN!</h1>
	<h1 style='margin:0;'>Recurso de Acceso Restringido</h1>				
	<p>Por estar sujetos a derechos de propiedad intelectual, el/los contenidos a los que trata de acceder permanecen en <span style='color: red;
    font-weight: bold;'>estricta restricción</span>.</p>
</div>";
header('location: ../');