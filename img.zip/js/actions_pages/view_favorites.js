$('.delete_p').on('click', function(){
    alert('Deseas eliminar este producto?');
})