// function Changetxt(){

// /////////////////////HEADER DEL HOME...
// var textHeader = [];

// var contentHeader =  {
// 	history : document.getElementById('history_t'),
// 	oficialM : document.getElementById('oficialmarkets_t'),
// 	ofertS : document.getElementById('weeklydeals_t'),
// 	starSelling : document.getElementById('startselling_t'),
// 	helpY : document.getElementById('helpyou_t')
// }

// window.onload = function ChangeText(){
// 	contentHeader['history'].textContent = "Historial";
// 	contentHeader['oficialM'].textContent = "Tiendas Oficiales";
// 	contentHeader['ofertS'].textContent = "Ofertas Semanales";
// 	contentHeader['starSelling'].textContent = "Vender";
// 	contentHeader['helpY'].textContent = "Ayuda";
// 	}
// }

// var contentHeader = {
// 	history : $('#history_t');
// 	oficialM : $('#oficialmarkets_t');
// 	ofertS : $('#weeklydeals_t');
// 	starSelling : $('#startselling_t');
// 	helpY : $('#helpyou_t'); 
// }

// $(document).ready(function Changetxt(){
// 	contentHeader['history'].val('Historial');
// 	contentHeader['oficialM'].val('Historial');
// 	contentHeader['ofertS'].val('Historial');
// 	contentHeader['starSelling'].val('Historial');
// 	contentHeader['helpY'].val('Historial');
// })


// $(function(){
// 	Changetxt();
// })