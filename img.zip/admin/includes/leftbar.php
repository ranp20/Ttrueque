<nav class="ts-sidebar" class="siderbar-left-admin">
  <ul class="ts-sidebar-menu" class="sidebar-left-menu">
    <label class="ts-label">Menú principal</label>
    <!-- INICIO -->
    <li>
      <a href="dashboard.php"><i class="fa fa-dashboard"></i>Dashboard</a>
    </li>
    <!-- OPCIONES DE PRODUCTOS -->
    <!-- <li class="sub_menu_items">
      <a href="#"><i class="fa fa-cart-arrow-down"></i>Productos</a>
      <ul>
        <li>
          <a href="add-items.php"><i class="fa fa-plus-square"></i>Añadir Productos</a>
        </li>
        <li>
          <a href="manage-items.php"><i class="fa fa-list-alt"></i>Listar Productos</a>
        </li>
        <li>
          <a href="#"><i class="fa fa-bitcoin"></i>Marcas</a>
        </li>
      </ul>
    </li> -->
    <!-- OPCIONES DE CATEGORÍA -->
    <li class="sub_menu_items">
      <a href="#"><i class="fa fa-files-o"></i>Categorías</a>
      <ul>
        <li>
          <a href="add-category.php"><i class="fa fa-plus-square"></i>Añadir Categoría</a>
        </li>
        <li>
          <a href="manage-category.php"><i class="fa fa-list-alt"></i>Listar Categorias</a>
        </li>
      </ul>
    </li>
    <!-- OPCIONES DE MEMBRESÍA -->
    <li class="sub_menu_items">
      <a href="#"><i class="fa fa-money"></i>Menbresías</a>
      <ul>
        <li>
          <a href="add-menbresia.php"><i class="fa fa-plus-square"></i>Añadir Menbresía</a>
        </li>
        <li>
          <a href="manage-menbresia.php"><i class="fa fa-list-alt"></i>Listar Menbresia</a>
        </li>
      </ul>
    </li>
    <!-- OPCIONES DE RECARGA DE PUNTOS -->
    <li class="sub_menu_items">
      <a href="#"><i class="fa fa-refresh"></i>Recargas</a>
      <ul>
        <li>
          <a href="add-recarga.php"><i class="fa fa-plus-square"></i>Añadir Recarga</a>
        </li>
        <li>
          <a href="manage_recargas.php"><i class="fa fa-list-alt"></i>Listar Recargas</a>
        </li>
      </ul>
    </li>
    <!-- OPCIONES DE USUARIOS -->
    <li>
      <a href="user-setup.php"><i class="fa fa-user"></i>Usuarios</a>
    </li>
    <!-- OPCIONES DE BANNERS -->
    <li>
      <a href="banners-setup.php"><i class="fa fa-image"></i>Banners</a>
    </li>
    <!-- OPCIONES DE PEDIDOS -->
    <!-- <li>
      <a href="manage-orders.php"><i class="fa fa-truck"></i>Pedidos</a>
    </li> -->
    <!-- OPCIONES DE PUNTUACIONES -->
    <!-- <li>
      <a href="manage-pointers.php"><i class="fa fa-star"></i>Puntuaciones</a>
    </li> -->
    <!-- OPCIONES DE FEEDBACK -->
    <li>
      <a href="manage-credentials.php"><i class="fa fa-credit-card"></i>Credenciales</a>
    </li>
    <!--<li>
      <a href="feedback.php"><i class="fa fa-commenting"></i>Feedback</a>
    </li>-->
    <!-- OPCIONES DE SUBCATEGORÍA -->
   <!--  <li class="sub_menu_items">
      <a href="#"><i class="fa fa-desktop"></i>Ajustes de Pantallas</a>
      <ul>
        <li>
          <a href="display-setup.php"><i class="fa fa-desktop"></i>Ajustes de Pantallas</a>
        </li>
        <li>
          <a href="#"><i class="fa fa-wrench"></i>Ajustes del Sitio</a>
        </li>
      </ul>
    </li> -->
    <!-- OPCIONES DE FEEDBACK -->
    <li>
      <a href="manage-admin.php"><i class="fa fa-lock"></i>Perfil Administrador</a>
    </li>
  </ul>
</nav>