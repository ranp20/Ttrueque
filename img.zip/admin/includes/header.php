<div class="brand clearfix" id="siderbar-header">
	<div class="content-header-sidebar">
		<div class="content-logo-sidebar-header">
			<a title="Trueque" href="dashboard.php">
				<img class="logo-admin-ttrk-login" src="../img/logo/Logo_TTRK.png" alt="logo_Ttrueque">
			</a>
		</div>
		<div class="cont-total-opts-header">
			<div class="content-ir-a-sitio">
				<a href="../" target="_blank" class="ir-al-sitio"><i class="fa fa-desktop"></i>Visitar el sitio</a>
			</div>
			<span class="menu-btn">
				<i class="fa fa-bars"></i>
			</span>
			<div class="content-user-options">
				<ul class="ts-profile-nav" class="user-s-sidebar-left">
					<li class="ts-account">
						<a href="#"><i class="fa fa-user"></i>Cuenta<i class="fa fa-angle-down hidden-side"></i></a>
						<ul>
							<li><a href="manage-admin.php"><i class="fa fa-pencil"></i>Perfil</a></li>
							<li><a href="logout.php"><i class="fa fa-remove"></i>Cerrar Sesión</a></li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
	</div>
</div>