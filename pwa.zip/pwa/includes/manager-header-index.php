<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
<meta name="description" content="">
<meta name="author" content="Ttrueque">
<!-- ADD CSS -->
<link rel="stylesheet" href="../shop/css/style.css">
<link rel="stylesheet" href="../shop/css/add-to-product.css">
<link rel="stylesheet" href="../shop/css/products_v.css">
<link rel="stylesheet" href="../shop/css/add-store.css">
<!-- ADD LINEICONS CDN-->
<link rel="stylesheet" href="https://cdn.lineicons.com/2.0/LineIcons.css">
<!-- ADD JQUERYCDN -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<!-- SWEEET ALERT 2-->
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
<!--//LINEICONS CDN-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.css">
<!--------- JQUERY PROVIDER-------->
<script src="js/jquery-3.3.1.min.js"></script>
<!-- CDN BOOTSTRAP -->
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8shuf57BaghqFfPlYxofvL8/KUEfYiJOMMV+rV" crossorigin="anonymous"></script>
<!-- STYLESSHEET INTO PWA-->
<link rel="stylesheet" href="css/styles.css">
<link rel="stylesheet" href="../css/customs/custom.css">