<section id="toppwa-ttrq" class="toppwa-ttrq">
	<div class="toppwa-ttrq__content container-maxwidth">
		<a href="javascript: history.go(-1)" id="gottobackpage-pwa" class="toppwa-ttrq__content--iconbackpage">
			<img src="img/icons/icon-arrow-left.svg" alt="" class="toppwa-ttrq__content--iconbackpage-icon">
		</a>
		<div class="toppwa-ttrq__content--img">
			<img src="img/logotipo-T-white.svg" alt="logotipo-Ttrueque-white.svg" class="toppwa-ttrq__content--img--logo">
		</div>
	</div>
</section>